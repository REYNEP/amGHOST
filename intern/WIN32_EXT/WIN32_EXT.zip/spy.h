/*
 * Message spying routines
 *
 * Copyright 1994, Bob Amstadt
 *           1995, Alex Korobka
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 */

/** https://github.com/mikemccormack/ring3k/blob/21dbdbb0eba96960f3f1da314b25a4f731719576/kernel/spy.cpp#L411 */

#ifndef __RING3K_SPY__
#define __RING3K_SPY__

#define WIN32_LEAN_AND_MEAN 1
#include <windows.h>
#include <wchar.h>

const char *spy_get_message_name( UINT message );

#endif // __RING3K_SPY__
